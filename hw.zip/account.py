from tkinter import *
from tkinter.ttk import Button
from tkinter.ttk import Entry
from tkinter import ttk
from signUp import *

def in_account(login):
    acc_win = Tk()
    acc_win.title("Аккаунт пользователя")
    acc_win.geometry("360x500")

    tab = ttk.Notebook(acc_win)
    logIn = ttk.Frame(tab)
    SignUp = ttk.Frame(tab)
    tab.add(logIn, text="Личный кабинет")
    tab.add(SignUp, text="Настройки")

    l_login = Label(logIn, text=f"Аккаунт пользователя: {login}", font=("Arial Bold", 15))
    l_login.grid(column=0, row=0)



    tab.pack(expand=1, fill='both')
    acc_win.mainloop()